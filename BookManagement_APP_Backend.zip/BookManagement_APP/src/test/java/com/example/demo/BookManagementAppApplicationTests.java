package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
 


@SpringBootTest(classes = BookManagementAppApplication.class)
public class BookManagementAppApplicationTests {

    @Test
    void contextLoads() {
        // Test if Spring Boot context loads
    }
}

