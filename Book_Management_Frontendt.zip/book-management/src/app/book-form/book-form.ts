import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, ReactiveFormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { BookService } from '../services/bookservice';
import { HttpClientModule } from '@angular/common/http';

@Component({
  selector: 'app-book-form',
  standalone: true,
  templateUrl: './book-form.html',
  styleUrls: ['./book-form.css'],
  imports: [CommonModule, ReactiveFormsModule, HttpClientModule]
})
export class BookForm implements OnInit {
  bookForm!: FormGroup;
  isEdit: boolean = false;
  currentIsbn!: string;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private bookService: BookService
  ) {}

  ngOnInit() {
    this.bookForm = new FormGroup({
      isbn: new FormControl('', Validators.required),
      title: new FormControl('', Validators.required),
      author: new FormControl('', Validators.required),
      publicationYear: new FormControl('', [
        Validators.required,
        Validators.pattern('^[0-9]{4}$')
      ])
    });

    const isbn = this.route.snapshot.paramMap.get('isbn');
    if (isbn) {
      this.isEdit = true;
      this.currentIsbn = isbn;

      this.bookService.getBookByIsbn(this.currentIsbn).subscribe({
        next: (book: any) => {
          this.bookForm.patchValue(book);
        },
        error: () => {
          alert('Failed to load book data');
        }
      });
    }
  }

  onSubmit() {
    if (this.bookForm.invalid) {
      alert('Please fill all fields');
      return;
    }

    if (this.isEdit) {
      this.bookService.updateBook(this.currentIsbn, this.bookForm.value).subscribe({
        next: () => {
          alert('Book updated successfully!');
          this.router.navigate(['/books']);
        },
        error: () => alert('Failed to update book')
      });
    } else {
      this.bookService.addBook(this.bookForm.value).subscribe({
        next: () => {
          alert('Book added successfully!');
          this.router.navigate(['/books']);
        },
        error: () => alert('Failed to add book')
      });
    }
  }
}
