import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Router, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-login',
  standalone: true,
  templateUrl: './login.html',
  styleUrls: ['./login.css'],
  imports: [CommonModule, ReactiveFormsModule, RouterModule, HttpClientModule]  // ✅ fixed here
})
export class Login {
  loginForm: FormGroup;

  constructor(private fb: FormBuilder, private http: HttpClient, private router: Router) {
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required]
    });
  }

  onSubmit(): void {
    if (this.loginForm.invalid) {
      alert('Enter email and password.');
      return;
    }

    this.http.post<any>('http://localhost:9090/api/auth/login', this.loginForm.value).subscribe({
      next: (response) => {
        localStorage.setItem('token', response.token);  // ✅ Just the string
         

        this.router.navigate(['/books']);
      },
      error: () => alert('Invalid credentials.')
    });
  }
}
